from darelabdb.utils_database_connector.core import Database


def get_db():
    return Database("fc4eosc")
