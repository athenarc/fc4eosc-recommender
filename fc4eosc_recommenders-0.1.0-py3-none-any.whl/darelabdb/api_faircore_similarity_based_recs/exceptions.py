class ItemNotFound(BaseException):
    pass
