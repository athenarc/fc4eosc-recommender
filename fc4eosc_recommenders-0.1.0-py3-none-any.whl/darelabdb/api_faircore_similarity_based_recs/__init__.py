from darelabdb.api_faircore_similarity_based_recs import core

__all__ = ["core"]
