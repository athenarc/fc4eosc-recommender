from darelabdb.utils_configs import core

__all__ = ["core"]
